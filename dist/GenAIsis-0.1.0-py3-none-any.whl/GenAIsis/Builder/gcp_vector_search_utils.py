import os
import numpy as np
import openai
from google.cloud import aiplatform
from google.oauth2 import service_account
from pymongo import MongoClient
from pymongo.errors import OperationFailure, AutoReconnect
import json
from bson import ObjectId
import logging
from typing import List, Optional
from fastapi import HTTPException

# Configure logging
LOGGER = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def generate_query_embedding(query: str) -> np.ndarray:
    """Generate an embedding for the query using the Azure OpenAI model."""
    openai.api_key = os.environ["AZURE_OPENAI_API_KEY"]
    openai.api_base = os.environ["AZURE_OPENAI_ENDPOINT"]
    openai.api_version = os.environ["OPENAI_API_VERSION"]

    try:
        LOGGER.info("Generating query embedding", stack_info=True, exc_info=True)
        response = openai.embeddings.create(
            model=os.environ["AZURE_DEPLOYMENT_EMBEDDING"],
            input=query
        )
        embedding = response.data[0].embedding
        LOGGER.info("Query embedding generated successfully", stack_info=True, exc_info=True)
        return np.array(embedding)
    except openai.error.OpenAIError as e:
        LOGGER.error(f"Error generating embedding from OpenAI API: {e}", stack_info=True, exc_info=True)
        raise ValueError("Error generating embedding from OpenAI API.")
    except Exception as e:
        LOGGER.error(f"Unexpected error generating embedding: {e}", stack_info=True, exc_info=True)
        raise ValueError("Unexpected error generating embedding.")
def vector_search_find_neighbors(query: str, customer_id: str= None, session_identifier: Optional[str] = None):
    """Query the vector search index and return the nearest neighbors."""
    try:
        LOGGER.info("Starting vector search for neighbors", stack_info=True, exc_info=True)
        
        # Validate required environment variables
        required_vars = [
            "GCP_PROJECT_ID",
            "GCP_REGION",
            "GCP_INDEX_ENDPOINT_NAME",
            "GCP_DEPLOYED_INDEX_ID",
            "NUM_NEIGHBORS"
        ]
        for var in required_vars:
            if not os.environ.get(var):
                LOGGER.error(f"Environment variable {var} is not set.", stack_info=True, exc_info=True)
                raise ValueError(f"Environment variable {var} is not set.")

        # Extract GCP configurations
        project_id = os.environ["GCP_PROJECT_ID"]
        region = os.environ["GCP_REGION"]
        index_endpoint_name = os.environ["GCP_INDEX_ENDPOINT_NAME"]
        deployed_index_id = os.environ["GCP_DEPLOYED_INDEX_ID"]
        num_neighbors = int(os.environ["NUM_NEIGHBORS"])

        # Initialize Google Cloud AI Platform
        credentials_path = os.environ.get("VERTEXAI_CREDENTIALS_PATH")
        if credentials_path:
            creds = service_account.Credentials.from_service_account_file(credentials_path)
            aiplatform.init(project=project_id, location=region, credentials=creds)
        else:
            aiplatform.init(project=project_id, location=region)

        # Generate the query embedding
        embedding = generate_query_embedding(query)
        if not embedding.any():
            raise ValueError("Error generating embedding from custom method")

        my_index_endpoint = aiplatform.MatchingEngineIndexEndpoint(
            index_endpoint_name=index_endpoint_name
        )

        # Create filter using customer_id and session_identifier
        filters = [
            aiplatform.matching_engine.matching_engine_index_endpoint.Namespace("customer_id", [customer_id], [])
        ]
        if session_identifier:
            filters.append(aiplatform.matching_engine.matching_engine_index_endpoint.Namespace("session_identifier", [session_identifier], []))
        
        LOGGER.info(f"Filters being passed to vector search: {filters}")

        # Perform vector search
        vector_search_response = my_index_endpoint.find_neighbors(
            deployed_index_id=deployed_index_id,
            queries=[embedding.tolist()],
            num_neighbors=num_neighbors,
            filter=filters
        )

        if not vector_search_response or not vector_search_response[0]:
            raise ValueError("Vector search response is empty or invalid")

        # Process results (only return IDs and distances)
        responses = [{"id": neighbor.id, "distance": neighbor.distance} for neighbor in vector_search_response[0]]

        LOGGER.info(f"Final responses: {responses}", stack_info=True, exc_info=True)
        return {"response": responses}

    except ValueError as e:
        LOGGER.error(f"ValueError: {e}", stack_info=True, exc_info=True)
        raise
    except Exception as e:
        LOGGER.error(f"An internal error occurred: {e}", stack_info=True, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))