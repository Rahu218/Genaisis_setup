from ..Components.ModelComponents import AzureChatOpenAIComponent, ChatVertexAIComponent
from ..Components.PromptComponent import PromptComponent


class ChatLLM:
    def __init__(self):
        self.final_prompt = None
        self.llm_chat = None
        self.parameters = dict()

    def __str__(self) -> str:
        return "Test"

    def build(self):
        return self.llm_chat.build(self.final_prompt, max_tokens=self.parameters['max_tokens'],
                                   temperature=self.parameters['temperature'])


class ChatLLMBuilder:
    def __init__(self, rag_model_response=None):
        if rag_model_response is None:
            self.rag_model_response = ChatLLM()
        else:
            self.rag_model_response = rag_model_response

    @property
    def llm_chat(self):
        return ChatLLMModelBuilder(self.rag_model_response)

    def set_prompt(self, template: str, **kwargs):
        self.rag_model_response.final_prompt = PromptComponent().build(template, **kwargs)
        return self

    def build(self):
        return self.rag_model_response.build()


class ChatLLMModelBuilder(ChatLLMBuilder):
    def __init__(self, rag_model_response):
        super().__init__(rag_model_response)

    def chat_azure_openai(self, max_tokens: int = 128, temperature: float = 1):
        self.rag_model_response.llm_chat = AzureChatOpenAIComponent()
        self.rag_model_response.parameters['max_tokens'] = max_tokens
        self.rag_model_response.parameters['temperature'] = temperature
        return self

    def chat_google_vertexai(self, max_tokens: int = 128, temperature: float = 1):
        self.rag_model_response.llm_chat = ChatVertexAIComponent()
        self.rag_model_response.parameters['max_tokens'] = max_tokens
        self.rag_model_response.parameters['temperature'] = temperature
        return self


__all__ = ['ChatLLMBuilder']
