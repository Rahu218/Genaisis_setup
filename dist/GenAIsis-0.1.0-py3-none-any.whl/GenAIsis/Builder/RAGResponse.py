from ..Components.EmbeddingsComponents import AzureOpenAIEmbeddingsComponent, \
    VertexAIEmbeddingsComponent
from ..Components.ModelComponents import AzureChatOpenAIComponent
from ..Components.PromptComponent import PromptComponent
from ..Prompts.InternalPrompt import prompt1


class RAGResponse:
    def __init__(self):
        self.vector_search_model = None
        self.embedding_model = None
        self.question = None
        self.llm_chat = None
        self.parameters = dict()
        self.final_prompt = None

    def __str__(self) -> str:
        return "Test"

    def build(self):
        records = self.vector_search_model.build(input_value=self.question,
                                                 embedding=self.embedding_model,
                                                 number_of_results=self.parameters['number_of_results'],
                                                 metadata_filter=self.parameters['metadata_filter'],
                                                 search_type=self.parameters['search_type'],
                                                 where_document=self.parameters['where_document'])

        kwargs = {"context": records, "question": self.question}
        if self.final_prompt:
            print(self.final_prompt)
            final_prompt = PromptComponent().build(self.final_prompt, **kwargs)
        else:
            print(prompt1)
            final_prompt = PromptComponent().build(prompt1, **kwargs)
        return self.llm_chat.build(final_prompt, max_tokens=self.parameters['max_tokens'],
                                   temperature=self.parameters['temperature'])


class RAGResponseBuilder:
    def __init__(self, rag_model_response=None):
        if rag_model_response is None:
            self.rag_model_response = RAGResponse()
        else:
            self.rag_model_response = rag_model_response

    @property
    def embedding_model(self):
        return EmbeddingModelBuilder(self.rag_model_response)

    @property
    def vector_search(self):
        return VectorSearchBuilder(self.rag_model_response)

    @property
    def llm_chat(self):
        return LLMBuilder(self.rag_model_response)

    def set_question(self, question):
        self.rag_model_response.question = question
        return self

    def set_prompt(self, template: str):
        self.rag_model_response.final_prompt = template
        return self

    def build(self):
        return self.rag_model_response.build()


class VectorSearchBuilder(RAGResponseBuilder):
    def __init__(self, rag_model_response):
        super().__init__(rag_model_response)

    def search(self,
               search_type: str = "Similarity",
               number_of_results: int = 4, metadata_filter: dict = None, where_document: dict = None):
        self.rag_model_response.parameters['search_type'] = search_type
        self.rag_model_response.parameters['number_of_results'] = number_of_results
        self.rag_model_response.parameters['metadata_filter'] = metadata_filter
        self.rag_model_response.parameters['where_document'] = where_document

        return self


class EmbeddingModelBuilder(RAGResponseBuilder):
    def __init__(self, rag_model_response):
        super().__init__(rag_model_response)

    def azure_embeddings(self):
        self.rag_model_response.embedding_model = AzureOpenAIEmbeddingsComponent().build()
        return self

    def vertex_embeddings(self):
        self.rag_model_response.embedding_model = VertexAIEmbeddingsComponent().build()
        return self


class LLMBuilder(RAGResponseBuilder):
    def __init__(self, rag_model_response):
        super().__init__(rag_model_response)

    def chat_azure_openai(self, max_tokens: int = 128, temperature: float = 1):
        self.rag_model_response.llm_chat = AzureChatOpenAIComponent()
        self.rag_model_response.parameters['max_tokens'] = max_tokens
        self.rag_model_response.parameters['temperature'] = temperature
        return self

    def chat_google_vertexai(self, max_tokens: int = 128, temperature: float = 1):
        self.rag_model_response.llm_chat = AzureChatOpenAIComponent()
        self.rag_model_response.parameters['max_tokens'] = max_tokens
        self.rag_model_response.parameters['temperature'] = temperature
        return self


__all__ = ['RAGResponseBuilder']
