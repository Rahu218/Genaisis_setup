from typing import Optional, Any, Union

from ..Components.DataExtractorComponents import URLComponent, DirectoryComponent, FileComponent, VideoComponent, \
    StreamComponent, ImageComponent
from ..Components.EmbeddingsComponents import AzureOpenAIEmbeddingsComponent, \
    VertexAIEmbeddingsComponent
from ..Components.TextSplitterComponents import RecursiveCharacterTextSplitterComponent, \
    CharacterTextSplitterComponent
from ..Components.VectorStoreComponents import GCPVectorStoreComponent


class VectorDBStore:
    def __init__(self):
        self.data_extracted = None
        self.text_splitter = None
        self.embedding_model = None
        self.vector_store = None
        self.parameters = dict()

    def __str__(self) -> str:
        return "Test"

    def build(self, customer_id=None, username=None,common_id=None, user_id=None, title=None, session_identifier=None,datapoint_ids=None):
        docs = self.text_splitter.build(inputs=self.data_extracted, chunk_size=self.parameters['chunk_size'],
                                        chunk_overlap=self.parameters['chunk_overlap'])
        if isinstance(self.vector_store, GCPVectorStoreComponent):
            self.vector_store.build(embedding=self.embedding_model, inputs=docs, customer_id=customer_id, username=username, user_id=user_id, title=title, session_identifier=session_identifier,common_id=common_id,datapoint_ids=datapoint_ids)
        else:
            raise ValueError("Unsupported vector store component")


class VectorDBStoreBuilder:
    def __init__(self, save_data=None):
        if save_data is None:
            self.save_data = VectorDBStore()
        else:
            self.save_data = save_data

    @property
    def data_extractor(self):
        return DataExtractorBuilder(self.save_data)

    @property
    def text_splitter(self):
        return TextSplittersBuilder(self.save_data)

    @property
    def embedding_model(self):
        return EmbeddingModelBuilder(self.save_data)

    @property
    def vector_store(self):
        return DBBuilder(self.save_data)

    def build(self, customer_id: str, username: str, user_id: str, title: str, session_identifier: Optional[str] = None, common_id=None,datapoint_ids=None):
        self.save_data.build(customer_id=customer_id, username=username, user_id=user_id, title=title, session_identifier=session_identifier, common_id=common_id,datapoint_ids=datapoint_ids)
        return self.save_data


class DataExtractorBuilder(VectorDBStoreBuilder):
    def __init__(self, save_data):
        super().__init__(save_data)

    def file_data_extraction(self, path: str = None, metadata: dict = None):
        self.save_data.data_extracted = [FileComponent().build(path=path, metadata=metadata)]
        return self

    def directory_data_extraction(self, path: str, depth: Optional[int] = 1, metadata: dict = None):
        self.save_data.data_extracted = DirectoryComponent().build(path=path, depth=depth, metadata=metadata)
        return self

    def url_data_extraction(self, urls: list[str], metadata: dict = None):
        self.save_data.data_extracted = URLComponent().build(urls=urls, metadata=metadata)
        return self

    def stream_data_extraction(self, stream: Any, file_name: Optional[str] = None, metadata: dict = None):
        if metadata is None:
            metadata = {}
        if file_name:
            metadata['file_name'] = file_name
        self.save_data.data_extracted = [StreamComponent().build(stream=stream, metadata=metadata)]
        return self

    def video_data_extraction(self, source: Union[str, bytes], max_output_tokens: Optional[int] = 2048,
                              temperature: Optional[float] = 0.5, top_p: Optional[int] = 1,
                              top_k: Optional[int] = 32, metadata: dict = None):
        self.save_data.data_extracted = [VideoComponent().build(
            source=source,
            max_output_tokens=max_output_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            metadata=metadata
        )]
        return self

    def image_data_extraction(self, source: Union[str, bytes], max_output_tokens: Optional[int] = 2048,
                              temperature: Optional[float] = 0.5, top_p: Optional[int] = 1,
                              top_k: Optional[int] = 32, metadata: dict = None):
        self.save_data.data_extracted = [ImageComponent().build(
            source=source,
            max_output_tokens=max_output_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            metadata=metadata
        )]
        return self


class TextSplittersBuilder(VectorDBStoreBuilder):
    def __init__(self, save_data):
        super().__init__(save_data)

    def recursive_character_splitter(self, chunk_size: Optional[int] = 1000, chunk_overlap: Optional[int] = 200):
        self.save_data.text_splitter = RecursiveCharacterTextSplitterComponent()
        self.save_data.parameters['chunk_size'] = chunk_size
        self.save_data.parameters['chunk_overlap'] = chunk_overlap
        return self

    def character_splitter(self, chunk_size: Optional[int] = 1000, chunk_overlap: Optional[int] = 200):
        self.save_data.text_splitter = CharacterTextSplitterComponent()
        self.save_data.parameters['chunk_size'] = chunk_size
        self.save_data.parameters['chunk_overlap'] = chunk_overlap
        return self


class EmbeddingModelBuilder(VectorDBStoreBuilder):
    def __init__(self, save_data):
        super().__init__(save_data)

    def azure_embeddings(self):
        self.save_data.embedding_model = AzureOpenAIEmbeddingsComponent().build()
        return self

    def vertex_embeddings(self):
        self.save_data.embedding_model = VertexAIEmbeddingsComponent().build()
        return self


class DBBuilder(VectorDBStoreBuilder):
    def __init__(self, save_data):
        super().__init__(save_data)

    def gcp_vector_store(self, index_name: Optional[str] = None, project_id: Optional[str] = None, region: Optional[str] = None, credentials_path: Optional[str]= None,index_endpoint_name: Optional[str] = None):
        """
        Sets up the GCP Vertex AI Matching Engine as the vector store.

        Parameters:
        - index_name (str): The ID of the GCP Matching Engine index.
        - project_id (str, optional): The GCP project ID. If not provided, reads from environment.
        - region (str, optional): The GCP region. If not provided, reads from environment.

        Returns:
        - DBBuilder: Returns the DBBuilder instance for chaining.
        """
        try:
            # Create the GCPVectorStoreComponent instance
            self.save_data.vector_store = GCPVectorStoreComponent(
                index_name=index_name,
                project_id=project_id,
                index_endpoint_name=index_endpoint_name,
                region=region,
                credentials_path=credentials_path
            )
            
            # Set parameters
            self.save_data.parameters['index_name'] = index_name
            self.save_data.parameters['project_id'] = project_id
            self.save_data.parameters['region'] = region
            self.save_data.parameters['credentials_path'] = credentials_path
            
            # Log the setup
        
            return self
        except Exception as e:
            # Log error if setup fails
            raise e

# __all__ = ['VectorDBStoreBuilder']