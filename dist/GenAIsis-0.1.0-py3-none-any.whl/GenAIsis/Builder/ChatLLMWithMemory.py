from ..Components.ModelComponents import AzureChatOpenAIComponent, ChatVertexAIComponent
from ..Components.PromptComponent import PromptComponent
from ..utils.langchain.buffer import ConversationBufferMemory
from ..utils.langchain.conversation_chain import ConversationChain


class ChatLLMWithMemory:
    def __init__(self):
        self.final_prompt = None
        self.question = None
        self.llm = None
        self.parameters = dict()
        self.memory = ConversationBufferMemory(memory_key="chat_history")
        self.chain = None

    def __str__(self) -> str:
        return "Test"

    def build(self):
        if self.chain is None:
            # self.chain = LLMChain(llm=self.llm, verbose=True, memory=ConversationBufferMemory())
            self.chain = ConversationChain(llm=self.llm, verbose=True, memory=ConversationBufferMemory())
        result = self.chain.predict(input=self.question)
        if isinstance(result, dict):
            result = result.get(chain.output_key, "")  # type: ignore
        elif isinstance(result, str):
            result = result
        else:
            result = result.get("response")
        return str(result)


class ChatLLMWithMemoryBuilder:
    def __init__(self, rag_model_response=None):
        if rag_model_response is None:
            self.rag_model_response = ChatLLMWithMemory()
        else:
            self.rag_model_response = rag_model_response

    @property
    def llm_chat(self):
        return ChatLLMWithMemoryModelBuilder(self.rag_model_response)

    def set_prompt(self, template: str, **kwargs):
        self.rag_model_response.final_prompt = PromptComponent().build(template, **kwargs)
        return self

    def set_question(self, question):
        self.rag_model_response.question = question
        return self

    def build(self):
        return self.rag_model_response.build()


class ChatLLMWithMemoryModelBuilder(ChatLLMWithMemoryBuilder):

    def __init__(self, rag_model_response):
        super().__init__(rag_model_response)

    def chat_azure_openai(self):
        self.rag_model_response.llm = AzureChatOpenAIComponent().build(specs=True, input_value="Blank")
        return self

    def chat_google_vertexai(self):
        self.rag_model_response.llm = ChatVertexAIComponent().build(specs=True, input_value="Blank")
        return self


__all__ = ['ChatLLMWithMemoryBuilder']
