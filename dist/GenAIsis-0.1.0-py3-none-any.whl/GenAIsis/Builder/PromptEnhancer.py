from dotenv import load_dotenv

load_dotenv()

from ..Components.PromptComponent import PromptComponent
from ..Components.ModelComponents import AzureChatOpenAIComponent, ChatVertexAIComponent


class PromptEnhance:
    def __init__(self):
        self.final_prompt = None
        self.llm_chat = None
        self.parameters = dict()
        self.initial_prompt = None
        # self.template = '''Enhance the below prompt by comprehensively analyzing the following parameters to ensure better outcomes:
        #                 prompt: "{initial_prompt}"
        #                 Role: Identify the specific roles involved in the scenario and their responsibilities.
        #                 Type of Data: Specify the types of data being used or analyzed.
        #                 Relationship: Describe the relationships between different data elements.
        #                 Constraints: Outline any constraints or limitations that need to be considered.
        #                 Steps for Analysis: Detail the steps required for analyzing the data.
        #                 Output Instructions: Provide clear instructions on the expected output.
        #                 Restrictions: Mention any restrictions or specific rules that must be followed.
        #                 Data Organization: Explain how the data is organized or structured.
        #             If any of these parameters are understandable or have existing information, do not make assumptions but instead, enhance the prompt by including them explicitly to ensure clarity and precision. The goal is to create a prompt that is fully detailed and comprehensive, facilitating accurate and insightful analysis.All enhancements should be integrated into a single, comprehensive paragraph.'''
        self.template = '''You are an AI prompt generator. Your task is to generate dynamic prompts based on two 
        input parameters: {category} and {subcategory}. The prompts you generate will be used to create commands for 
        {category} {subcategory}. Use the following structure to guide your prompt generation:

        Start with a clear role definition, such as "You are a helpful assistant that generates commands for 
        {category} {subcategory} based on user input." Specify that the response should contain only commands and no 
        explanation or code. Clearly outline that the assistant will only respond with the necessary {subcategory} 
        command to find a solution for the user input. Ensure the generated commands are formatted with syntax for 
        the {subcategory}.'''

    def __str__(self) -> str:
        return "Test"

    def build(self):
        # self.final_prompt = PromptComponent().build(self.template, self.initial_prompt)
        return self.llm_chat.build(self.final_prompt, max_tokens=self.parameters['max_tokens'],
                                   temperature=self.parameters['temperature'])


class PromptEnhanceBuilder:
    def __init__(self, prompt_enhance=None):
        if prompt_enhance is None:
            self.prompt_enhance = PromptEnhance()
        else:
            self.prompt_enhance = prompt_enhance

    @property
    def llm(self):
        return PromptEnhanceLLMModelBuilder(self.prompt_enhance)

    @property
    def enhance_type(self):
        return PromptEnhanceTypeBuilder(self.prompt_enhance)

    # def set_prompt(self, initial_prompt):
    #     # print(type(kwargs))
    #     kwargs = {"initial_prompt": initial_prompt}
    #     self.prompt_enhance.final_prompt = PromptComponent().build(self.prompt_enhance.template, **kwargs)
    #     return self

    def set_prompt(self, kwargs):
        self.prompt_enhance.final_prompt = PromptComponent().build(self.prompt_enhance.template, **kwargs)
        return self

    # def set_prompt(self, initial_prompt):
    #     self.prompt_enhance.initial_prompt = initial_prompt
    #     return self

    def build(self):
        return self.prompt_enhance.build()


class PromptEnhanceTypeBuilder(PromptEnhanceBuilder):
    def __init__(self, prompt_enhance):
        super().__init__(prompt_enhance)

    def static(self):
        self.prompt_enhance.enhance_type = 'Static'
        return self

    def dynamic(self):
        self.prompt_enhance.enhance_type = 'Dynamic'
        return self


class PromptEnhanceLLMModelBuilder(PromptEnhanceBuilder):
    def __init__(self, prompt_enhance):
        super().__init__(prompt_enhance)

    def azure_openai(self, max_tokens: int = 128, temperature: float = 1):
        self.prompt_enhance.llm_chat = AzureChatOpenAIComponent()
        self.prompt_enhance.parameters['max_tokens'] = max_tokens
        self.prompt_enhance.parameters['temperature'] = temperature
        return self

    def google_vertexai(self, max_tokens: int = 128, temperature: float = 1):
        self.prompt_enhance.llm_chat = ChatVertexAIComponent()
        self.prompt_enhance.parameters['max_tokens'] = max_tokens
        self.prompt_enhance.parameters['temperature'] = temperature
        return self


__all__ = ['PromptEnhanceBuilder']
