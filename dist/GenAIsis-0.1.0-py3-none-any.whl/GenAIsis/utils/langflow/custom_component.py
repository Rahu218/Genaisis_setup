from pathlib import Path
from typing import Any, ClassVar, Optional, Union
from uuid import UUID

from cachetools import TTLCache

from ..langflow import dotdict, validate
from ..langflow.component import Component


class CustomComponent(Component):
    """
    Represents a custom component in Langflow.

    Attributes:
        display_name (Optional[str]): The display name of the custom component.
        description (Optional[str]): The description of the custom component.
        code (Optional[str]): The code of the custom component.
        field_config (dict): The field configuration of the custom component.
        code_class_base_inheritance (ClassVar[str]): The base class name for the custom component.
        function_entrypoint_name (ClassVar[str]): The name of the function entrypoint for the custom component.
        function (Optional[Callable]): The function associated with the custom component.
        repr_value (Optional[Any]): The representation value of the custom component.
        user_id (Optional[Union[UUID, str]]): The user ID associated with the custom component.
        status (Optional[Any]): The status of the custom component.
        _tree (Optional[dict]): The code tree of the custom component.
    """
    field_config: dict = {}
    frozen: Optional[bool] = False
    """The edge target parameter of the component. Defaults to None."""
    code_class_base_inheritance: ClassVar[str] = "CustomComponent"

    _tree: Optional[dict] = None

    def __init__(self, **data):
        """
        Initializes a new instance of the CustomComponent class.

        Args:
            **data: Additional keyword arguments to initialize the custom component.
        """
        self.cache = TTLCache(maxsize=1024, ttl=60)
        super().__init__(**data)

    @staticmethod
    def resolve_path(path: str) -> str:
        """Resolves the path to an absolute path."""
        path_object = Path(path)
        if path_object.parts[0] == "~":
            path_object = path_object.expanduser()
        elif path_object.is_relative_to("."):
            path_object = path_object.resolve()
        return str(path_object)

    def build_config(self):
        """
        Builds the configuration for the custom component.

        Returns:
            dict: The configuration for the custom component.
        """
        return self.field_config

    def update_build_config(
            self,
            build_config: dotdict,
            field_value: Any,
            field_name: Optional[str] = None,
    ):
        build_config[field_name] = field_value
        return build_config

    def get_function(self):
        """
        Gets the function associated with the custom component.

        Returns:
            Callable: The function associated with the custom component.
        """
        return validate.create_function(self.code, self.function_entrypoint_name)

    def build(self, *args: Any, **kwargs: Any) -> Any:
        """
        Builds the custom component.

        Args:
            *args: The positional arguments.
            **kwargs: The keyword arguments.

        Returns:
            Any: The result of the build process.
        """
        raise NotImplementedError
