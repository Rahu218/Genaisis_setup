from typing import TYPE_CHECKING, Type

from ..langflow.validate import extract_class_name, create_class

if TYPE_CHECKING:
    from ..langflow.custom_component import CustomComponent


def eval_custom_component_code(code: str) -> Type["CustomComponent"]:
    """Evaluate custom component code"""
    class_name = extract_class_name(code)
    return create_class(code, class_name)
