import time
from functools import wraps

from ..utils.logging import LOGGER


def calls_count(func_name):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            elapsed_time = end_time - start_time
            LOGGER.debug(f"Execution time of {func_name}: {elapsed_time:.4f} seconds")
            return result

        return wrapper

    return decorator
