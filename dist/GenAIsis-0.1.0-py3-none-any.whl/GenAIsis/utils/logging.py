import logging.config

logging.config.fileConfig("logging.conf")
LOGGER = logging.getLogger()
