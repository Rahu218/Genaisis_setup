prompt1 = """{context}\n\n---\n\nGiven the context above, answer the question as good as possible.

Question: {question}

Answer:"""
