import os
from typing import List, Optional, Union, Text

from dotenv import load_dotenv
from langchain_core.messages.base import BaseMessage
from langchain_openai import AzureChatOpenAI
from pydantic.v1 import SecretStr

from ..utils.decorators import calls_count
from ..utils.langflow.constants import STREAM_INFO_TEXT
from ..utils.langflow.model import LCModelComponent

load_dotenv()
from google.oauth2 import service_account
from abc import ABC, abstractmethod
from langchain_core.language_models.chat_models import BaseChatModel
from ..utils.langflow.custom_component import CustomComponent
import vertexai
from vertexai.generative_models import GenerativeModel


# import vertexai.preview.generative_models as generative_models

class ModelComponent(ABC):
    """
    Abstract class for Model components.

    This class defines the interface that should be implemented by all Model components.
    """

    description: str = "Base class for generating model chat instances"
    documentation: str = "Abstract class for Model components."

    @abstractmethod
    def build_config(self):
        """
        Builds the configuration for the Model component.

        Returns:
            A dictionary containing the configuration for the Model component.
        """
        pass

    @abstractmethod
    def build(self, **kwargs) -> Text:
        """
        Builds the Model component.

        Args:
            **kwargs: keyword arguments specific to the Model component being built.

        Returns:
            Text
        """
        pass


class AzureChatOpenAIComponent(ModelComponent):
    description: str = "Generate text using Azure OpenAI LLMs."
    documentation: str = "https://python.langchain.com/docs/integrations/llms/azure_openai"

    AZURE_OPENAI_MODELS = [
        "gpt-35-turbo",
        "gpt-35-turbo-16k",
        "gpt-35-turbo-instruct",
        "gpt-4",
        "gpt-4-32k",
        "gpt-4-vision",
    ]

    AZURE_OPENAI_API_VERSIONS = [
        "2023-03-15-preview",
        "2023-05-15",
        "2023-06-01-preview",
        "2023-07-01-preview",
        "2023-08-01-preview",
        "2023-09-01-preview",
        "2023-12-01-preview",
    ]

    def __init__(self):
        try:
            self.api_key = os.environ["AZURE_OPENAI_API_KEY"]
            self.azure_endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
            self.azure_deployment = os.environ["AZURE_DEPLOYMENT"]
            self.api_version = os.environ["OPENAI_API_VERSION2"]
            self.model = os.environ["OPENAI_MODEL_NAME"]
        except KeyError:
            raise KeyError("Set following environment variables: AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, "
                           "AZURE_DEPLOYMENT, OPENAI_API_VERSION, OPENAI_MODEL_NAME")

        if self.api_key is None or self.azure_endpoint is None or self.azure_deployment is None or self.api_version is None or self.model is None:
            raise ValueError("Set following environment variables: AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, "
                             "AZURE_DEPLOYMENT, OPENAI_API_VERSION, OPENAI_MODEL_NAME")

    def build_config(self):
        return {
            "model": {
                "value": self.AZURE_OPENAI_MODELS[0],
                "options": self.AZURE_OPENAI_MODELS,
            },
            "azure_endpoint": {
                "info": "Your Azure endpoint, including the resource.. Example: "
                        "`https://example-resource.azure.openai.com/`",
            },
            "azure_deployment": {
            },
            "api_version": {
                "options": self.AZURE_OPENAI_API_VERSIONS,
                "value": self.AZURE_OPENAI_API_VERSIONS[-1],
                "advanced": True,
            },
            "api_key": {"password": True},
            "temperature": {
                "value": 0.7,
            },
            "max_tokens": {
                "value": 1000,
                "info": "Maximum number of tokens to generate.",
            },
            "code": {"show": False},
            "input_value": {},
            "stream": {
                "info": STREAM_INFO_TEXT,
            },
            "system_message": {
                "info": "System message to pass to the model.",
            },
        }

    @calls_count("AzureChatOpenAIComponent.build")
    def build(
            self,
            input_value: Text,
            specs: bool = False,
            temperature: Optional[float] = 0.5,
            system_message: Optional[str] = None,
            max_tokens: Optional[int] = 1000,
            stream: bool = False,
    ) -> Union[Text, BaseChatModel]:
        secret_api_key = SecretStr(self.api_key)
        try:
            output = AzureChatOpenAI(
                model=self.model,
                azure_endpoint=self.azure_endpoint,
                azure_deployment=self.azure_deployment,
                api_version=self.api_version,
                api_key=self.api_key,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as e:
            raise ValueError("Could not connect to AzureOpenAI API.") from e
        if specs is True:
            return output
        return LCModelComponent().get_chat_result(output, stream, input_value, system_message)


class ChatVertexAIComponent(ModelComponent):
    description = "Generate text using Vertex AI LLMs."

    field_order = [
        "credentials",
        "project",
        "examples",
        "location",
        "max_output_tokens",
        "model_name",
        "temperature",
        "top_k",
        "top_p",
        "verbose",
        "input_value",
        "system_message",
        "stream",
    ]

    def build_config(self):
        return {
            "credentials": {
                "field_type": "file",
                "file_types": [".json"],
                "file_path": None,
            },
            "examples": {
                "multiline": True,
            },
            "location": {
                "value": "us-central1",
            },
            "max_output_tokens": {
                "value": 128,
                "advanced": True,
            },
            "model_name": {
                "value": "chat-bison",
            },
            "project": {
                "display_name": "Project",
            },
            "temperature": {
                "value": 0.0,
            },
            "top_k": {
                "value": 40,
                "advanced": True,
            },
            "top_p": {
                "value": 0.95,
                "advanced": True,
            },
            "verbose": {
                "value": False,
                "advanced": True,
            },
            "input_value": {"display_name": "Input"},
            "stream": {
                "info": STREAM_INFO_TEXT,
                "advanced": True,
            },
            "system_message": {
                "info": "System message to pass to the model.",
                "advanced": True,
            },
        }

    def __init__(self):
        try:
            credential_dir_path = os.environ["VERTEXAI_CREDENTIALS_PATH"]
        except KeyError:
            raise KeyError("Set VERTEXAI_CREDENTIALS_PATH environment variable")
        if not credential_dir_path:
            raise ValueError(
                "Set VERTEXAI_CREDENTIALS_PATH environment variable.")

        resolved_path = CustomComponent.resolve_path(credential_dir_path)
        self.credentials = service_account.Credentials.from_service_account_file(resolved_path)

        try:
            self.model_name = os.environ["VERTEXAI_CHAT_MODEL"]
        except KeyError:
            raise KeyError("Set VERTEXAI_CHAT_MODEL environment variable")
        if not self.model_name:
            raise ValueError(
                "Set VERTEXAI_CHAT_MODEL environment variable.")

    @calls_count("ChatVertexAIComponent.build")
    def build(
            self,
            input_value: Text,
            specs: bool = False,
            credentials: Optional[str] = None,
            examples: Optional[List[BaseMessage]] = [],
            max_tokens: int = 128,
            temperature: float = 1,
            top_k: int = 40,
            top_p: float = 0.95,
            verbose: bool = False,
            stream: bool = False,
            system_message: Optional[str] = None,
    ) -> Union[Text, BaseChatModel]:
        # try:
        #     from langchain_google_vertexai import ChatVertexAI
        # except ImportError:
        #     raise ImportError(
        #         "To use the ChatVertexAI model, you need to install the langchain-google-vertexai package."
        #     )
        #
        # output = ChatVertexAI(
        #     credentials=self.credentials,
        #     examples=examples,
        #     max_output_tokens=max_output_tokens,
        #     model_name=self.model_name,
        #     project=self.credentials.project_id,
        #     temperature=temperature,
        #     top_k=top_k,
        #     top_p=top_p,
        #     verbose=verbose,
        # )

        generation_config = {
            "max_output_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
        }
        # if specs is True:
        #     return output
        # return LCModelComponent().get_chat_result(output, stream, input_value, system_message)
        print(self.credentials.project_id)
        vertexai.init(project=self.credentials.project_id, credentials=self.credentials)
        model = GenerativeModel(
            self.model_name, system_instruction=system_message
        )
        responses = model.generate_content(
            contents=input_value,
            generation_config=generation_config,
            stream=stream,
        )

        # print(responses)
        # for response in responses:
        #     print(response.text, end="")

        return responses.text
