import os
import uuid
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Union
from dotenv import load_dotenv
from langchain_community.vectorstores import VectorStore
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.retrievers import BaseRetriever

from ..utils.langflow.custom_component import CustomComponent
from google.cloud.aiplatform.compat.types import (
    matching_engine_index as gca_matching_engine_index,
)
from google.cloud import aiplatform
from google.auth import credentials
from google.auth.transport.requests import Request
from google.oauth2 import service_account
from pymongo import MongoClient
from pymongo.errors import OperationFailure, AutoReconnect
from datetime import datetime, timezone

load_dotenv()

# Configure logging
LOGGER = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class VectorStoreComponent(ABC):
    """
    Abstract super class for all VectorStore components.
    """

    description: str = "Abstract VectorStore component"
    documentation: str = ""

    @abstractmethod
    def build_config(self) -> Dict:
        """
        Builds the configuration for the component.

        Returns:
        - dict: A dictionary containing the configuration options for the component.
        """
        pass

    @abstractmethod
    def build(self, **kwargs) -> Union[VectorStore, BaseRetriever]:
        """
        Builds the VectorStore or BaseRetriever component.

        Returns:
        - Union[VectorStore, BaseRetriever]: The built VectorStore or BaseRetriever component.
        """
        pass


class GCPVectorStoreComponent:
    """
    A custom component for implementing a Vector Store using GCP's Vertex AI Matching Engine.
    """

    def __init__(self, index_name: str, index_endpoint_name: str, project_id: str, region: str, credentials_path: Optional[str] = None, mongo_uri: str = None):
        # Initialize MongoDB client for storing metadata
        try:
            self.mongo_uri = os.environ["MONGO_URI"]
            self.db_name = os.environ["MONGO_DB_NAME"]
            self.collection_name = os.environ["MONGO_COLLECTION_NAME_METADATA"]
        except KeyError as e:
            LOGGER.error(f"Set {e.args[0]} environment variable", stack_info=True, exc_info=True)
            raise KeyError(f"Set {e.args[0]} environment variable")

        if not self.mongo_uri:
            LOGGER.error("MONGO_URI environment variable is not set", stack_info=True, exc_info=True)
            raise ValueError("MONGO_URI environment variable is not set")
        if not self.db_name or not isinstance(self.db_name, str):
            LOGGER.error("MONGO_DB_NAME environment variable is not set or is not a string", stack_info=True, exc_info=True)
            raise ValueError("MONGO_DB_NAME environment variable is not set or is not a string")
        if not self.collection_name or not isinstance(self.collection_name, str):
            LOGGER.error("MONGO_COLLECTION_NAME_METADATA environment variable is not set or is not a string", stack_info=True, exc_info=True)
            raise ValueError("MONGO_COLLECTION_NAME_METADATA environment variable is not set or is not a string")

        self.mongo_client = MongoClient(self.mongo_uri)
        self.db = self.mongo_client[self.db_name]  # Connect to the specified database
        self.metadata_collection = self.db[self.collection_name]  # Use the specified collection name

        self.project_id = os.environ["GCP_PROJECT_ID"]
        if not self.project_id:
            LOGGER.error("Project ID must be provided either as a parameter or via the GCP_PROJECT_ID environment variable.", stack_info=True, exc_info=True)
            raise ValueError("Project ID must be provided either as a parameter or via the GCP_PROJECT_ID environment variable.")

        self.region = os.environ["GCP_REGION"]
        if not self.region:
            LOGGER.error("Region must be provided either as a parameter or via the GCP_REGION environment variable.", stack_info=True, exc_info=True)
            raise ValueError("Region must be provided either as a parameter or via the GCP_REGION environment variable.")

        self.index_name = os.environ["GCP_INDEX_NAME"]
        if not self.index_name:
            LOGGER.error("Index name must be provided either as a parameter or via the GCP_INDEX_NAME environment variable.", stack_info=True, exc_info=True)
            raise ValueError("Index name must be provided either as a parameter or via the GCP_INDEX_NAME environment variable.")

        self.index_endpoint_name = os.environ["GCP_INDEX_ENDPOINT_NAME"]
        if not self.index_endpoint_name:
            LOGGER.error("Index endpoint name must be provided either as a parameter or via the GCP_INDEX_ENDPOINT_NAME environment variable.", stack_info=True, exc_info=True)
            raise ValueError("Index endpoint name must be provided either as a parameter or via the GCP_INDEX_ENDPOINT_NAME environment variable.")

        self.credentials_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")

        # If credentials_path is provided, explicitly set the credentials
        if self.credentials_path:
            try:
                creds = service_account.Credentials.from_service_account_file(self.credentials_path)
                aiplatform.init(project=self.project_id, location=self.region, credentials=creds)
                LOGGER.info(f"Initialized with credentials from {self.credentials_path}", stack_info=True, exc_info=True)
            except Exception as e:
                LOGGER.error(f"Failed to load credentials from {self.credentials_path}: {str(e)}", stack_info=True, exc_info=True)
                raise ValueError(f"Failed to load credentials from {self.credentials_path}: {str(e)}")
        else:
            # Use default credentials if no path is provided
            try:
                aiplatform.init(project=self.project_id, location=self.region)
                LOGGER.info("Initialized with default credentials", stack_info=True, exc_info=True)
            except Exception as e:
                LOGGER.error(f"Failed to initialize with default credentials: {str(e)}", stack_info=True, exc_info=True)
                raise ValueError(f"Failed to initialize with default credentials: {str(e)}")

        # Initialize GCP Vertex AI client
        self.index = aiplatform.MatchingEngineIndex(index_name=self.index_name)
        self.index_endpoint = aiplatform.MatchingEngineIndexEndpoint(index_endpoint_name=self.index_endpoint_name)

    def build_config(self):
        """
        Builds the configuration for the GCP Vector Store component.

        Returns:
        - dict: A dictionary containing the configuration options for the component.
        """
        return {
            "index_name": {
                "type": str,
                "required": True,
                "description": "The name of the GCP Vertex AI Matching Engine index.",
            },
            "index_endpoint_name": {
                "type": str,
                "required": True,
                "description": "The name of the GCP Vertex AI Matching Engine index endpoint.",
            },
            "project_id": {
                "type": str,
                "required": True,
                "description": "The GCP project ID.",
            },
            "region": {
                "type": str,
                "required": True,
                "description": "The GCP region where the index and endpoint are hosted.",
            },
            "mongo_uri": {
                "type": str,
                "required": True,
                "description": "The MongoDB URI for storing metadata.",
            },
            "credentials_path": {
                "type": str,
                "required": False,
                "description": "The path to the GCP service account credentials file. If not provided, default credentials are used.",
            },
            "embedding": {
                "type": 'Embeddings',
                "required": True,
                "description": "The embedding model to use for generating document embeddings.",
            },
            "inputs": {
                "type": List['Document'],
                "required": False,
                "description": "The list of documents to embed and store in the vector store.",
            }
        }

    def build(self, embedding: 'Embeddings', inputs: Optional[List['Document']] = None, customer_id: str = None, username: str = None, user_id: str = None, title: str = None, session_identifier: Optional[str] = None, common_id=None, datapoint_ids=None) -> 'BaseRetriever':
        if inputs is not None:
            embeddings = []
            datapoints = []  # Initialize the list of datapoints for GCP upsert

            # Ensure datapoint_ids length matches inputs
            if datapoint_ids and len(datapoint_ids) < len(inputs):
                missing_count = len(inputs) - len(datapoint_ids)
                generated_ids = [str(uuid.uuid4()) for _ in range(missing_count)]
                datapoint_id_list = datapoint_ids + generated_ids  # Combine provided and generated IDs
            elif datapoint_ids:
                datapoint_id_list = datapoint_ids
            else:
                datapoint_id_list = [str(uuid.uuid4()) for _ in inputs]

            for i, doc in enumerate(inputs):
                # Embed document content
                try:
                    embedding_vector = embedding.embed_documents([doc.page_content])
                    # Flatten the list if necessary
                    if isinstance(embedding_vector[0], list):
                        embedding_vector = embedding_vector[0]
                    embeddings.append(embedding_vector)
                    LOGGER.info(f"Generated embedding for document {i+1}", stack_info=True, exc_info=True)
                except Exception as e:
                    LOGGER.error(f"Failed to generate embedding for document {i+1}: {str(e)}", stack_info=True, exc_info=True)
                    raise ValueError(f"Failed to generate embedding for document {i+1}: {str(e)}")

                # Use the provided datapoint_id
                datapoint_id = datapoint_id_list[i]
                print(f"Datapoint ID for document {i+1}: {datapoint_id}")

                # Clean the content: remove excessive spaces and newlines
                clean_content = " ".join(doc.page_content.split())

                # Add document name to the metadata
                document_name = doc.metadata.get("file_name", f"Document_{i+1}")  # Use provided name or default to "Document_x"

                # Prepare the metadata
                metadata = {
                    "datapoint_id": datapoint_id,
                    "common_id": common_id,
                    "customer_id": customer_id,
                    "session_identifier": session_identifier,
                    "user_id": user_id,
                    "created_at": datetime.now(timezone.utc),
                    "created_by": username,
                    "content": clean_content,  # Use cleaned content here
                    "file_name": document_name,  # Include the document name
                    "title": title,
                    "updated_by": username,
                    "updated_at": datetime.now(timezone.utc)
                }

                # Insert the metadata into MongoDB
                try:
                    self.metadata_collection.insert_one(metadata)
                    LOGGER.info(f"Inserted metadata for document {i+1} into MongoDB", stack_info=True, exc_info=True)
                except OperationFailure as e:
                    LOGGER.error(f"MongoDB operation failed for document {i+1}: {e}", stack_info=True, exc_info=True)
                    raise
                except AutoReconnect as e:
                    LOGGER.error(f"MongoDB connection error for document {i+1}: {e}", stack_info=True, exc_info=True)
                    raise
                except Exception as e:
                    LOGGER.error(f"Error inserting metadata for document {i+1}: {e}", stack_info=True, exc_info=True)
                    raise

                # Prepare datapoint for GCP upsert
                restricts = [
                    gca_matching_engine_index.IndexDatapoint.Restriction(
                        namespace="customer_id", allow_list=[customer_id]
                    )
                ]
                if session_identifier:
                    restricts.append(
                        gca_matching_engine_index.IndexDatapoint.Restriction(
                            namespace="session_identifier", allow_list=[session_identifier]
                        )
                    )

                datapoint = gca_matching_engine_index.IndexDatapoint(
                    datapoint_id=datapoint_id,
                    feature_vector=embedding_vector,
                    restricts=restricts
                )
                print(f"Restricts for document {i+1}: {datapoint.restricts}")

                datapoints.append(datapoint)

            # Upsert datapoints to GCP Matching Engine
            if datapoints:
                try:
                    self.index.upsert_datapoints(datapoints)
                    LOGGER.info(f"Upserted {len(datapoints)} datapoints to GCP Matching Engine", stack_info=True, exc_info=True)
                except Exception as e:
                    LOGGER.error(f"Failed to upsert datapoints to GCP Matching Engine: {str(e)}", stack_info=True, exc_info=True)
                    raise ValueError(f"Failed to upsert datapoints to GCP Matching Engine: {str(e)}")

        # Return the GCP Matching Engine endpoint
        return self.index_endpoint
    def close(self):
        self.mongo_client.close()
        LOGGER.info("Closed MongoDB connection", stack_info=True, exc_info=True)
