import os
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Text

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from ..utils.langflow.model import LCVectorStoreComponent
from ..utils.langflow.schema import Record

load_dotenv()


class SearchComponent(ABC):
    """
    Abstract base class for search components.

    Attributes:
        description: A description of the search component.
    """

    @abstractmethod
    def build_config(self) -> Dict[str, Any]:
        """
        Returns a dictionary containing the configuration options for this component.

        Returns:
            Dict[str, Any]: A dictionary of configuration options.
        """
        pass

    @abstractmethod
    def build(self, **kwargs) -> List[Document]:
        """
        Builds the component and returns a list of documents.

        Args:
            **kwargs: Keyword arguments for the component.

        Returns:
            List[Any]: A list of documents.
        """
        pass