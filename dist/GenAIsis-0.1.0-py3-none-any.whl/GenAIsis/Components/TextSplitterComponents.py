from abc import ABC, abstractmethod
from typing import Optional, List

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_text_splitters.character import CharacterTextSplitter

from ..utils.langflow.util import unescape_string


class TextSplitterComponent(ABC):
    """
    Abstract class for text splitter components.

    Attributes:
        description (str): Description of the component.
        documentation (str): URL to the component's documentation.
    """

    description: str
    documentation: str

    @abstractmethod
    def build_config(self):
        """Builds the component configuration."""
        raise NotImplementedError

    @abstractmethod
    def build(
            self,
            inputs: List[Document],
            **kwargs,
    ) -> List[Document]:
        """Splits a list of documents into smaller documents.

        Args:
        inputs (List[Document]) : The input documents.

        Raises:
        NotImplementedError: This method must be implemented in concrete classes.

        Returns :
        List(Documents) : The output documents.

        """
        raise NotImplementedError


class RecursiveCharacterTextSplitterComponent(TextSplitterComponent):
    description: str = "Split text into chunks of a specified length."
    documentation: str = "https://docs.langflow.org/components/text-splitters#recursivecharactertextsplitter"

    def build_config(self):
        return {
            "inputs": {
                "info": "The texts to split.",
                "input_types": ["Document"],
                "is_list": True,
            },
            "separators": {
                "info": 'The characters to split on.\nIf left empty defaults to ["\\n\\n", "\\n", " ", ""].',
                "is_list": True,
            },
            "chunk_size": {
                "info": "The maximum length of each chunk.",
                "field_type": "int",
                "value": 1000,
            },
            "chunk_overlap": {
                "info": "The amount of overlap between chunks.",
                "field_type": "int",
                "value": 200,
            }
        }

    def build(
            self,
            inputs: List[Document],
            separators: Optional[list[str]] = None,
            chunk_size: Optional[int] = 1000,
            chunk_overlap: Optional[int] = 200,
    ) -> List[Document]:
        """
        Split text into chunks of a specified length.

        Args:
            separators (list[str]): The characters to split on.
            chunk_size (int): The maximum length of each chunk.
            chunk_overlap (int): The amount of overlap between chunks.
            length_function (function): The function to use to calculate the length of the text.

        Returns:
            list[str]: The chunks of text.
        """

        if separators == "" or separators is None:
            separators = None
        elif separators:
            # check if the separators list has escaped characters
            # if there are escaped characters, unescape them
            separators = [unescape_string(x) for x in separators]
        # Make sure chunk_size and chunk_overlap are ints
        if isinstance(chunk_size, str):
            chunk_size = int(chunk_size)
        if isinstance(chunk_overlap, str):
            chunk_overlap = int(chunk_overlap)
        if separators is not None:
            splitter = RecursiveCharacterTextSplitter(
                separators=separators,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
        else:
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
        docs = splitter.split_documents(inputs)
        return docs


class CharacterTextSplitterComponent(TextSplitterComponent):
    description = "Splitting text that looks at characters."
    documentation: str = "https://docs.langflow.org/components/text-splitters#charactertextsplitter"

    def build_config(self):
        return {
            "inputs": {"input_types": ["Document"], "is_list": True},
            "chunk_overlap": {"default": 200},
            "chunk_size": {"default": 1000},
            "separator": {"default": "\n"},
        }

    def build(
            self,
            inputs: List[Document],
            chunk_overlap: int = 200,
            chunk_size: int = 1000,
            separator: str = "\n",
    ) -> List[Document]:
        # separator may come escaped from the frontend
        separator = unescape_string(separator)
        # Make sure chunk_size and chunk_overlap are ints
        if isinstance(chunk_size, str):
            chunk_size = int(chunk_size)
        if isinstance(chunk_overlap, str):
            chunk_overlap = int(chunk_overlap)
        docs = CharacterTextSplitter(
            chunk_overlap=chunk_overlap,
            chunk_size=chunk_size,
            separator=separator,
        ).split_documents(inputs)
        return docs
