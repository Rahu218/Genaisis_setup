import io
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from google.auth import default
import numpy as np
import vertexai
from PIL import Image
from dotenv import load_dotenv
from easyocr import Reader
from google.oauth2 import service_account
from langchain_community.document_loaders.web_base import WebBaseLoader
from langchain_core.documents import Document
from vertexai.preview.generative_models import GenerativeModel, Part
import logging

# Initialize logger
LOGGER = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

from ..utils.langflow.custom_component import CustomComponent
from ..utils.langflow.schema import Record
from ..utils.langflow.util import parallel_load_records, retrieve_file_paths, \
    TEXT_FILE_TYPES, parse_text_file_to_record

load_dotenv()


class DataExtractorComponent(ABC):
    """
    Abstract base class for components that can load documents.
    """

    @abstractmethod
    def build_config(self) -> Dict[str, Any]:
        """
        Returns a dictionary containing the configuration options for this component.

        Returns:
            Dict[str, Any]: A dictionary of configuration options.
        """
        pass

    @abstractmethod
    def build(self, **kwargs) -> List[Any]:
        """
        Builds the component and returns a list of documents.

        Args:
            **kwargs: Keyword arguments for the component.

        Returns:
            List[Any]: A list of documents.
        """
        pass


class URLComponent(DataExtractorComponent):
    description = "Fetch content from one or more URLs."

    def build_config(self) -> Dict[str, Any]:
        return {
            "urls": {},
        }

    def build(
            self,
            urls: list[str], metadata: dict = None
    ) -> list[Document]:
        loader = WebBaseLoader(web_paths=urls)
        docs = loader.load()
        new_docs = []
        if metadata:
            for doc in docs:
                merged_metadata = {**doc.metadata, **metadata}
                new_doc = Document(
                    page_content=doc.page_content,
                    metadata=merged_metadata
                )
                new_docs.append(new_doc)
            return new_docs
        else:
            return docs


class DirectoryComponent(DataExtractorComponent):
    description = "Recursively load files from a directory."

    def build_config(self) -> Dict[str, Any]:
        return {
            "path": {},
            "types": {
                "info": "File types to load. Leave empty to load all types.",
            },
            "depth": {"info": "Depth to search for files."},
            "max_concurrency": {},
            "load_hidden": {
                "info": "If true, hidden files will be loaded.",
            },
            "recursive": {
                "info": "If true, the search will be recursive.",
            },
            "silent_errors": {
                "info": "If true, errors will not raise an exception.",
            },
            "use_multithreading": {
            },
        }

    def build(
            self,
            path: str,
            depth: int = 1,
            max_concurrency: int = 1,
            load_hidden: bool = True,
            recursive: bool = True,
            silent_errors: bool = False,
            use_multithreading: bool = True,
            metadata: dict = None
    ) -> List[Document]:
        resolved_path = CustomComponent.resolve_path(path)
        file_paths = retrieve_file_paths(resolved_path, load_hidden, recursive, depth)
        if use_multithreading:
            loaded_records = parallel_load_records(file_paths, silent_errors, max_concurrency)
        else:
            loaded_records = [parse_text_file_to_record(file_path, silent_errors) for file_path in file_paths]
        loaded_records = list(filter(None, loaded_records))
        # result_string = records_to_text(template="Data: {data}, ", records=loaded_records)
        documents = []
        for _input in loaded_records or []:
            if isinstance(_input, Record):
                documents.append(_input.to_lc_document())
            else:
                documents.append(_input)
        new_documents = []
        for doc in documents:
            new_doc = Document(
                page_content=doc.page_content,
                metadata={
                    "file_path": doc.metadata["file_path"],
                    "file_name": os.path.basename(doc.metadata["file_path"])
                }
            )
            new_documents.append(new_doc)
        new_documents2 = []
        if metadata:
            for doc in new_documents:
                merged_metadata = {**doc.metadata, **metadata}
                new_doc = Document(
                    page_content=doc.page_content,
                    metadata=merged_metadata
                )
                new_documents2.append(new_doc)
            return new_documents2
        else:
            return new_documents


class FileComponent(DataExtractorComponent):
    description = ("A generic file loader. Supported file types: txt, md, mdx, csv, json, yaml, yml, xml, html, htm, "
                   "pdf, docx, py, sh, sql, js, ts, tsx")

    def build_config(self) -> Dict[str, Any]:
        return {
            "path": {
                "field_type": "file",
                "file_types": TEXT_FILE_TYPES,
                "info": f"Supported file types: {', '.join(TEXT_FILE_TYPES)}",
            },
            "silent_errors": {
                "info": "If true, errors will not raise an exception.",
            },
        }

    def build(
            self,
            path: str,
            silent_errors: bool = False, metadata: dict = None
    ) -> Document:
        if path:
            resolved_path = CustomComponent.resolve_path(path)
            path_obj = Path(resolved_path)
            extension = path_obj.suffix[1:].lower()
            if extension == "doc":
                raise ValueError("doc files are not supported. Please save as .docx")
            if extension not in TEXT_FILE_TYPES:
                raise ValueError(f"Unsupported file type: {extension}")
            record = parse_text_file_to_record(resolved_path, silent_errors)
            doc = record.to_lc_document()
            new_doc = Document(
                page_content=doc.page_content,
                metadata={
                    "file_path": doc.metadata["file_path"],
                    "file_name": os.path.basename(doc.metadata["file_path"])
                }
            )

            merged_metadata = {**new_doc.metadata, **metadata}
            new_doc2 = Document(
                page_content=new_doc.page_content,
                metadata=merged_metadata
            )
            return new_doc2
        # elif text:
        #     doc = Document(page_content=text)
        #     return doc
        else:
            raise ValueError("'path' must be provided.")


class VideoComponent(DataExtractorComponent):

    def __init__(self):
        try:
            self.model = os.environ["VERTEXAI_VIDEO_MODAL_NAME"]
        except KeyError:
            raise KeyError("Set VERTEXAI_VIDEO_MODAL_NAME environment variable")
        if not self.model:
            raise ValueError(
                "Set VERTEXAI_VIDEO_MODAL_NAME environment variable. Please provide a valid model name.")

        self.credentials_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")

        # If credentials_path is provided, explicitly set the credentials
        if self.credentials_path:
            try:
                self.credentials = service_account.Credentials.from_service_account_file(self.credentials_path)
                LOGGER.info(f"Initialized with credentials from {self.credentials_path}", stack_info=True, exc_info=True)
            except Exception as e:
                LOGGER.error(f"Failed to load credentials from {self.credentials_path}: {str(e)}", stack_info=True, exc_info=True)
                raise ValueError(f"Failed to load credentials from {self.credentials_path}: {str(e)}")
        else:
            # Use default credentials if no path is provided
            try:
                self.credentials, _ = default()
                LOGGER.info("Initialized with default credentials", stack_info=True, exc_info=True)
            except Exception as e:
                LOGGER.error(f"Failed to initialize with default credentials: {str(e)}", stack_info=True, exc_info=True)
                raise ValueError(f"Failed to initialize with default credentials: {str(e)}")

    def build_config(self) -> Dict[str, Any]:
        pass

    def build(self, source: Union[str, bytes], max_output_tokens: Optional[int] = 2048,
              temperature: Optional[float] = 0.5,
              top_p: Optional[int] = 1, top_k: Optional[int] = 32, metadata: dict = None) -> Document:
        credentials = self.credentials
        model = self.model
        vertexai.init(credentials=credentials)
        model = GenerativeModel(model)
        if isinstance(source, str):
            video1 = Part.from_uri(source, mime_type="video/mp4")
            filename = os.path.basename(source)
        elif isinstance(source, bytes):
            video1 = Part.from_data(source, mime_type="video/mp4")
            filename = "uploaded_video.mp4"
        else:
            raise ValueError("source must be a string or a file path (str) or a file object (bytes).")

        responses = model.generate_content(
            [
                """Provide a description of the video. Also write a detailed steps followed in video along with any 
                commands used""",
                video1],
            generation_config={
                "max_output_tokens": max_output_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "top_k": top_k
            },
        )

        document = Document(page_content=responses.text, metadata={"file_path": source, "file_name": filename})
        if metadata is None:
            metadata = {}
        merged_metadata = {**document.metadata, **metadata}
        new_doc = Document(
            page_content=document.page_content,
            metadata=merged_metadata
        )
        return new_doc


class StreamComponent(DataExtractorComponent):
    description = "Process and return a document from a provided stream."

    def build_config(self) -> Dict[str, Any]:
        return {
            "stream": {
                "info": "The stream to be processed.",
            },
            "metadata": {
                "info": "Optional metadata to be added to the document.",
            },
        }

    def build(self, stream: Any, metadata: dict = None) -> Document:
        content = stream.read()
        doc = Document(
            page_content=content,
            metadata={}
        )

        if metadata:
            merged_metadata = {**doc.metadata, **metadata}
            doc = Document(
                page_content=doc.page_content,
                metadata=merged_metadata
            )

        return doc


class ImageComponent(DataExtractorComponent):

    def __init__(self):
        # Initialize environment variables and credentials
        try:
            self.model = os.environ["VERTEXAI_IMAGE_MODAL_NAME"]
        except KeyError:
            raise KeyError("Set VERTEXAI_IMAGE_MODAL_NAME environment variable")
        if not self.model:
            raise ValueError("Set VERTEXAI_IMAGE_MODAL_NAME environment variable. Please provide a valid model name.")

        try:
            credential_dir_path = os.environ["VERTEXAI_CREDENTIALS_PATH"]
        except KeyError:
            raise KeyError("Set VERTEXAI_CREDENTIALS_PATH environment variable")
        if not credential_dir_path:
            raise ValueError("Set VERTEXAI_CREDENTIALS_PATH environment variable.")

        resolved_path = CustomComponent.resolve_path(credential_dir_path)
        self.credentials = service_account.Credentials.from_service_account_file(resolved_path)

        # Initialize EasyOCR reader
        self.reader = Reader(['en'])

    def build_config(self) -> Dict[str, Any]:
        # Implement any specific configuration if needed
        pass

    def build(self, source: Union[str, bytes], max_output_tokens: Optional[int] = 2048,
              temperature: Optional[float] = 0.5, top_p: Optional[int] = 1, top_k: Optional[int] = 32,
              metadata: dict = {}) -> Document:
        if isinstance(source, str):
            # Handle local file path
            if not os.path.isfile(source):
                raise FileNotFoundError(f"The file at path {source} does not exist.")
            image = Image.open(source)
            filename = os.path.basename(source)
        elif isinstance(source, bytes):
            # Handle file object
            image = Image.open(io.BytesIO(source))
            filename = "uploaded_image.jpg"
        else:
            raise ValueError("Source must be a file path (str) or a file object (bytes).")

        # Use EasyOCR to extract text from image
        results = self.reader.readtext(np.array(image))
        text = ' '.join([result[1] for result in results])

        document = Document(page_content=text, metadata={"file_path": source, "file_name": filename})
        if metadata is None:
            metadata = {}
        merged_metadata = {**document.metadata, **metadata}
        new_doc = Document(
            page_content=document.page_content,
            metadata=merged_metadata
        )
        return new_doc
