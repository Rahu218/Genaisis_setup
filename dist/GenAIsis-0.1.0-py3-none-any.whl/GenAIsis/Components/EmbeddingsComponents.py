import os
from abc import ABC, abstractmethod
from typing import List, Optional

from dotenv import load_dotenv
from langchain_core.embeddings import Embeddings
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings

from ..utils.langflow.custom_component import CustomComponent

load_dotenv()
from google.oauth2 import service_account


class EmbeddingsComponent(ABC):
    """
    Abstract class for Embeddings components.

    This class defines the interface that should be implemented by all Embeddings components.
    """

    description: str = "Base class for generating text embeddings."
    documentation: str = "Abstract class for Embeddings components."

    @abstractmethod
    def build_config(self):
        """
        Builds the configuration for the Embeddings component.

        Returns:
            A dictionary containing the configuration for the Embeddings component.
        """
        pass

    @abstractmethod
    def build(self, **kwargs) -> Embeddings:
        """
        Builds the Embeddings component.

        Args:
            **kwargs: keyword arguments specific to the Embeddings component being built.

        Returns:
            An object that can be used to generate embeddings.
        """
        pass


class AzureOpenAIEmbeddingsComponent(EmbeddingsComponent):
    description: str = "Generate embeddings using Azure OpenAI models."
    documentation: str = "https://python.langchain.com/docs/integrations/text_embedding/azureopenai"

    def __init__(self):
        try:
            self.azure_endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
            self.azure_deployment = os.environ["AZURE_DEPLOYMENT_EMBEDDING"]
            self.api_version = os.environ["OPENAI_API_VERSION"]
            self.api_key = os.environ["AZURE_OPENAI_API_KEY"]
        except KeyError:
            raise KeyError("Set following environment variables: AZURE_OPENAI_ENDPOINT, AZURE_DEPLOYMENT_EMBEDDING, "
                           "OPENAI_API_VERSION, AZURE_OPENAI_API_KEY")

        if self.azure_endpoint is None or self.azure_deployment is None or self.api_version is None or self.api_key is None:
            raise ValueError("Set following environment variables: AZURE_OPENAI_ENDPOINT, AZURE_DEPLOYMENT_EMBEDDING, "
                             "OPENAI_API_VERSION, AZURE_OPENAI_API_KEY")

    def build_config(self):
        return {
            "azure_endpoint": {
                "required": True,
                "info": "Your Azure endpoint, including the resource.. Example: "
                        "`https://example-resource.azure.openai.com/`",
            },
            "azure_deployment": {
                "required": True,
            },
            "api_version": {
                "required": True,
            },
            "api_key": {
                "display_name": "API Key",
                "required": True,
                "password": True,
            }
        }

    def build(self) -> Embeddings:
        try:
            embeddings = AzureOpenAIEmbeddings(
                azure_endpoint=self.azure_endpoint,
                azure_deployment=self.azure_deployment,
                api_version=self.api_version,
                api_key=self.api_key)
        except Exception as e:
            raise ValueError("Could not connect to AzureOpenAIEmbeddings API.") from e
        return embeddings


class VertexAIEmbeddingsComponent(EmbeddingsComponent):
    description = "Generate embeddings using Google Cloud VertexAI models."

    def __init__(self):
        try:
            credential_dir_path = os.environ["VERTEXAI_CREDENTIALS_PATH"]
        except KeyError:
            raise KeyError("Set VERTEXAI_CREDENTIALS_PATH environment variable")
        if not credential_dir_path:
            raise ValueError(
                "Set VERTEXAI_CREDENTIALS_PATH environment variable.")

        resolved_path = CustomComponent.resolve_path(credential_dir_path)
        self.credentials = service_account.Credentials.from_service_account_file(resolved_path)

        try:
            self.model_name = os.environ["VERTEXAI_EMBEDDING_MODEL"]
        except KeyError:
            raise KeyError("Set VERTEXAI_EMBEDDING_MODEL environment variable")
        if not self.model_name:
            raise ValueError(
                "Set VERTEXAI_EMBEDDING_MODEL environment variable.")

    def build_config(self):
        return {
            "credentials": {
                "display_name": "Credentials",
                "value": "",
                "file_types": [".json"],
                "field_type": "file",
            },
            "instance": {
                "display_name": "instance",
                "advanced": True,
                "field_type": "dict",
            },
            "location": {
                "display_name": "Location",
                "value": "us-central1",
                "advanced": True,
            },
            "max_output_tokens": {"display_name": "Max Output Tokens", "value": 128},
            "max_retries": {
                "display_name": "Max Retries",
                "value": 6,
                "advanced": True,
            },
            "model_name": {
                "display_name": "Model Name",
                "value": "textembedding-gecko",
            },
            "n": {"display_name": "N", "value": 1, "advanced": True},
            "project": {"display_name": "Project", "advanced": True},
            "request_parallelism": {
                "display_name": "Request Parallelism",
                "value": 5,
                "advanced": True,
            },
            "stop": {"display_name": "Stop", "advanced": True},
            "streaming": {
                "display_name": "Streaming",
                "value": False,
                "advanced": True,
            },
            "temperature": {"display_name": "Temperature", "value": 0.0},
            "top_k": {"display_name": "Top K", "value": 40, "advanced": True},
            "top_p": {"display_name": "Top P", "value": 0.95, "advanced": True},
        }

    def build(
            self,
            instance: Optional[str] = None,
            location: str = "us-central1",
            max_output_tokens: int = 128,
            max_retries: int = 6,
            n: int = 1,
            project: Optional[str] = None,
            request_parallelism: int = 5,
            stop: Optional[List[str]] = None,
            streaming: bool = False,
            temperature: float = 0.0,
            top_k: int = 40,
            top_p: float = 0.95,
    ) -> VertexAIEmbeddings:
        return VertexAIEmbeddings(
            credentials=self.credentials,
            # location=location,
            max_output_tokens=max_output_tokens,
            max_retries=max_retries,
            model_name=self.model_name,
            n=n,
            project=self.credentials.project_id,
            request_parallelism=request_parallelism,
            stop=stop,
            streaming=streaming,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
        )
