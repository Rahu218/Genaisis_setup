from typing import Text

from langchain_core.prompts import PromptTemplate

from ..utils.langflow.constants import Prompt
from ..utils.langflow.util import dict_values_to_string


class PromptComponent:
    description: str = "Create a prompt template with dynamic variables."

    def build(
            self,
            template: Prompt,
            **kwargs,
    ) -> Text:
        prompt_template = PromptTemplate.from_template(Text(template))
        kwargs = dict_values_to_string(kwargs)
        kwargs = {k: "\n".join(v) if isinstance(v, list) else v for k, v in kwargs.items()}
        try:
            formatted_prompt = prompt_template.format(**kwargs)
        except Exception as exc:
            raise ValueError(f"Error formatting prompt: {exc}") from exc
        return formatted_prompt
